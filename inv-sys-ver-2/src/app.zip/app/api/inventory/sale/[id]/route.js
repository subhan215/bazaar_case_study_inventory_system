import { NextResponse } from "next/server";
import { authenticateStore } from "../../../../../../middleware/authStore";
import pool from "../../../../../../database/database";
import redis from "../../../../../../utils/redis";

export async function POST(req, { params }) {
    const { storeId } = await authenticateStore(req);
    if (!storeId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const client = await pool.connect();
    const { id } = await params;
    if (storeId != parseInt(id)) {
        return NextResponse.json({ error: "Unauthorized store access" }, { status: 403 });
    }

    try {
        const { sku, quantity } = await req.json();
        await client.query("BEGIN");

        // ✅ **Cache Check: Get Product ID & Selling Price from Redis**
        const productCacheKey = `product:${sku}`;
        let productData = await redis.get(productCacheKey);

        if (!productData) {
            // Fetch from DB if not in cache
            const productRes = await client.query(
                "SELECT product_id, selling_price FROM products WHERE sku = $1",
                [sku]
            );

            if (productRes.rows.length === 0) throw new Error("Product not found");

            productData = productRes.rows[0];

            // Store in Redis for future requests (Expire in 10 minutes)
            await redis.set(productCacheKey, JSON.stringify(productData), "EX", 600);
        } else {
            productData = JSON.parse(productData);
        }

        const { product_id, selling_price } = productData;
        const totalSellingPrice = selling_price * quantity;

        // ✅ **Cache Check: Get Inventory Data from Redis**
        const inventoryCacheKey = `inventory:${storeId}`;
        let inventoryData = await redis.get(inventoryCacheKey);

        if (!inventoryData) {
            // Fetch from DB if not in cache
            const stockRes = await client.query(
                `SELECT inventory_id, supplier_id, quantity, purchase_price, updated_at
                 FROM inventory 
                 WHERE store_id = $1 AND product_id = $2 
                 ORDER BY purchase_price ASC, updated_at ASC`,
                [storeId, product_id]
            );

            if (stockRes.rows.length === 0) throw new Error("No stock available for this product");

            inventoryData = stockRes.rows;
            // Store in Redis (Expire in 5 minutes)
            await redis.set(inventoryCacheKey, JSON.stringify(inventoryData), "EX", 300);
        } else {
            inventoryData = JSON.parse(inventoryData);
        }

        let remainingQuantity = quantity;
        let totalCost = 0;

        for (const row of inventoryData) {
            if (remainingQuantity <= 0) break;

            const { inventory_id, quantity: availableStock, purchase_price } = row;
            const deductQuantity = Math.min(availableStock, remainingQuantity);

            await client.query(
                "UPDATE inventory SET quantity = quantity - $1 WHERE inventory_id = $2",
                [deductQuantity, inventory_id]
            );

            remainingQuantity -= deductQuantity;
            totalCost += deductQuantity * purchase_price;
        }

        if (remainingQuantity > 0) {
            throw new Error("Not enough stock available to fulfill the order");
        }

        const profit = totalSellingPrice - totalCost;

        // ✅ **Insert Sale into Database**
        await client.query(
            `INSERT INTO sales (store_id, product_id, quantity, total_price, profit, timestamp) 
             VALUES ($1, $2, $3, $4, $5, NOW())`,
            [storeId, product_id, quantity, totalSellingPrice, profit]
        );

        await client.query("COMMIT");

        // **🔴 Invalidate Cache After Sale**
        await redis.del(inventoryCacheKey); // Remove inventory cache
        await redis.del(`sales:${storeId}`); // Remove sales cache

        console.log(`✅ Cache cleared: ${inventoryCacheKey}, sales:${storeId}`);

        return NextResponse.json({
            success: true,
            message: "Sale recorded successfully",
            totalSellingPrice,
            profit,
        });

    } catch (error) {
        await client.query("ROLLBACK");
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    } finally {
        client.release();
    }
}
