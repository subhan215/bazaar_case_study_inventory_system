import { NextResponse } from "next/server";
import pool from "../../../../../database/database";
import { authenticateStore } from "../../../../../middleware/authStore";
export async function POST(req) {
    const { success, storeId } = await authenticateStore(req); 
    if (!success) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    storeId
    const client = await pool.connect();
    const { name, contact, address } = await req.json();

    try {
        const result = await client.query(
            `INSERT INTO supplier_requests (store_id, supplier_name, contact_details, address, status) 
             VALUES ($1, $2, $3, $4, 'pending') RETURNING *`,
            [storeId, name, contact, address]
        );
        return NextResponse.json({ success: true, request: result.rows[0] });
    } catch (error) {
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    } finally {
        client.release();
    }
}
