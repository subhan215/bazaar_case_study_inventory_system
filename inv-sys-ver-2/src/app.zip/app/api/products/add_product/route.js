import { NextResponse } from "next/server";
import pool from "../../../../../database/database";
import { authenticateAdmin } from "../../../../../middleware/authAdmin";
import redis from "../../../../../utils/redis"; // Import Redis

export async function POST(req) {
    const { success } = await authenticateAdmin(req);
    if (!success) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const client = await pool.connect();
    const { sku, name, selling_price } = await req.json();

    try {
        let result;
        if (selling_price !== undefined) {
            // Insert with selling_price if provided
            result = await client.query(
                "INSERT INTO products (sku, name, selling_price) VALUES ($1, $2, $3) RETURNING *",
                [sku, name, selling_price]
            );
        } else {
            // Insert without selling_price if not provided
            result = await client.query(
                "INSERT INTO products (sku, name) VALUES ($1, $2) RETURNING *",
                [sku, name]
            );
        }

        // ✅ **Invalidate the cache after product creation**
        await redis.del("products:all");

        return NextResponse.json({ success: true, product: result.rows[0] });
    } catch (error) {
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    } finally {
        client.release();
    }
}
