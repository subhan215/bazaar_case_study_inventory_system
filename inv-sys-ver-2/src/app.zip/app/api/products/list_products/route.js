import { NextResponse } from "next/server";
import pool from "../../../../../database/database";
import redis from "../../../../../utils/redis";

export async function GET() {
    const client = await pool.connect();
    const cacheKey = "products:all";

    try {
        // ✅ **Check Cache First**
        const cachedData = await redis.get(cacheKey);

        if (cachedData) {
            console.log("✅ Serving from cache");
            return NextResponse.json(JSON.parse(cachedData));
        }

        // ❌ If no cache, fetch from DB
        console.log("🔍 Fetching from database...");
        const result = await client.query("SELECT * FROM products");

        // ✅ **Store Result in Cache (expires in 10 minutes)**
        await redis.set(cacheKey, JSON.stringify(result.rows), "EX", 600); 

        return NextResponse.json(result.rows);

    } catch (error) {
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    } finally {
        client.release();
    }
}
